package Client;

public class InformationPanel {

}
