package Server;

import java.io.IOException;
import java.util.Vector;

public class ItemController {
	
	protected  GameItem itemList;
	
	public ItemController() throws IOException
	{
		itemList = new GameItem();
	}
}

