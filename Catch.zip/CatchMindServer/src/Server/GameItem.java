package Server;

import java.util.Vector;

public class GameItem {
	private int numMoreExp;
	private int numMoreCoin;
	private int numMoreCoin2;
	
	
	
	
	public GameItem() {
		// TODO Auto-generated constructor stub
		this.setNumMoreExp(0);
		this.setNumMoreCoin(0);
		this.setNumMoreCoin2(0);
	}
	
	public GameItem(int numMoreExp , int numMoreCoin, int numMoreCoin2)
	{

		this.setNumMoreExp(numMoreExp);
		this.setNumMoreCoin(numMoreCoin);
		this.setNumMoreCoin2(numMoreCoin2);
	}

	
	




	public int getNumMoreExp() {
		return numMoreExp;
	}

	public void setNumMoreExp(int numMoreExp) {
		this.numMoreExp = numMoreExp;
	}

	public int getNumMoreCoin() {
		return numMoreCoin;
	}

	public void setNumMoreCoin(int numMoreCoin) {
		this.numMoreCoin = numMoreCoin;
	}

	public int getNumMoreCoin2() {
		return numMoreCoin2;
	}

	public void setNumMoreCoin2(int numMoreCoin2) {
		this.numMoreCoin2 = numMoreCoin2;
	}
	
	public void buyMoreExp() {
		this.numMoreExp++;
	}
	
	public void useMoreExp() {
		this.numMoreExp--;
	}
	
	public void buyMoreCoin() {
		this.numMoreCoin++;
	}
	
	public void useMoreCoin() {
		this.numMoreCoin--;
	}
	
	public void buyMoreCoin2() {
		this.numMoreCoin2++;
	}
	
	public void useMoreCoin2() {
		this.numMoreCoin2--;
	}
	

}